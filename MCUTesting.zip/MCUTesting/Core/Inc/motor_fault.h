/*
 * motor_fault.h
 *
 *  Created on: Jul 28, 2025
 *      Author: dell
 */

#ifndef INC_MOTOR_FAULT_H_
#define INC_MOTOR_FAULT_H_


uint32_t Check_Hall_Stuck_Fault(void);

#endif /* INC_MOTOR_FAULT_H_ */
